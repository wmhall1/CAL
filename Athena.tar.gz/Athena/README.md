## Athena

This repository contains a local copy of the Athena MHD code.  This is only intended for use within the Simon Research Group at Iowa State University and is not the official version of the code (which can be found on the Princeton GitHub site). Unlike the official version, this version will contain all problem files, modifications, etc. that were specifically added by the research group. 
