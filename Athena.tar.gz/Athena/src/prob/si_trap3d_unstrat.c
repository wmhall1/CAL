#include "copyright.h"
/*==============================================================================
 * FILE: si_trap3d.c
 *
 * PURPOSE: Problem generator for streaming instability test in non-stratified
 *   disks. This code works in 3D, with single particle species ONLY. Isothermal
 *   eos is assumed, and the value etavk/iso_sound is fixed. 
 *
 * Perturbation modes:
 *    ipert = 0: no perturbation, test for the NSH equilibrium, need FARGO
 *    ipert = 1: no perturbation, no NSH equilibrium - all perturbed velocities = 0
 *    ipert = 3: random perturbation (warm start), do not need FARGO
 *  Must be configured using --enable-shearing-box and --with-eos=isothermal.
 *  FARGO is need to establish the NSH equilibrium (ipert=0,1,2).
 *
 * Reference:
 *   Youdin & Johansen, 2007, ApJ, 662, 613
 *   Johansen & Youdin, 2007, ApJ, 662, 627
 *   Bai & Stone,       2010, ApJS, 190, 297
 *   Taki et al.,       2016, A&A, 591, A86
 *============================================================================*/

#include <float.h>
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include "defs.h"
#include "athena.h"
#include "globals.h"
#include "prototypes.h"
#include "particles/particle.h"

#ifndef SHEARING_BOX
#error : The streaming2d problem requires shearing-box to be enabled.
#endif /* SHEARING_BOX */

#ifndef PARTICLES
#error : The streaming2d problem requires particles to be enabled.
#endif /* PARTICLES */

#ifndef ISOTHERMAL
#error : The streaming2d problem requires isothermal equation of state.
#endif /* ISOTHERMAL */

/*------------------------ filewide global variables -------------------------*/
/* NSH equilibrium parameters */
Real rho0, mratio, etavk, uxNSH, uyNSH, wxNSH, wyNSH;
/* particle number related variables */
int Npar,Npar3,downsamp,Nx;
/* perturbation variables */
Real amp, width, kx, kz, time_restore;
int ipert, par_pert, nwave;
/* output filename */
char name[50];

/*==============================================================================
 * PRIVATE FUNCTION PROTOTYPES:
 * ran2()            - random number generator
 * ShearingBoxPot()  - shearing box tidal gravitational potential
 * pert_???()        - perturbation wave form for linear growth rate test
 * property_mybin()  - particle property selection function 
 * property_???()    - particle property selection function
 *============================================================================*/
double ran2(long int *idum);
static Real UnstratifiedDisk(const Real x1, const Real x2, const Real x3);
static Real pert_even(Real fR, Real fI, Real x, Real z, Real t);
static Real pert_odd(Real fR, Real fI, Real x, Real z, Real t);
static int property_mybin(const GrainS *gr, const GrainAux *grsub);
extern Real expr_V1par(const GridS *pG, const int i, const int j, const int k);
extern Real expr_V2par(const GridS *pG, const int i, const int j, const int k);
extern Real expr_V3par(const GridS *pG, const int i, const int j, const int k);
extern Real expr_V3(const GridS *pG, const int i, const int j, const int k);

/*=========================== PUBLIC FUNCTIONS =================================
 *============================================================================*/
/*----------------------------------------------------------------------------*/
/* problem:   */

void problem(DomainS *pDomain)
{
  GridS *pGrid = pDomain->Grid;
  int i,j,k,ip,jp,kp,interp,ixs,jxs,kxs;
  long p;
  Real x1,x2,x3,t,x1l,x1u,x2l,x2u,x3l,x3u,x1p,x2p,x3p,paramp,factor2,reduct;
  Real x1min,x1max,x2min,x2max,x3min,x3max,Lx,Ly,Lz;
  Real rhog,cs,u1,u2,u3,w1,w2,w3,Kxn,Kzn,denorm1;
  long int iseed; /* Initialize on the first call to ran2 */

/* Ensure a different initial random seed for each process in an MPI calc. */
  ixs = pGrid->Disp[0];
  jxs = pGrid->Disp[1];
  kxs = pGrid->Disp[2];
  iseed = -1 - (ixs + pDomain->Nx[0]*(jxs + pDomain->Nx[1]*kxs));

  if (pDomain->Nx[2] == 1) {
    ath_error("[si_trap3d]: si_trap3d only works in 3D.\n");
  }

/* Initialize boxsize */
  x1min = pDomain->RootMinX[0];
  x1max = pDomain->RootMaxX[0];
  Lx = x1max - x1min;

  x2min = pDomain->RootMinX[1];
  x2max = pDomain->RootMaxX[1];
  Ly = x2max - x2min;

  x3min = pDomain->RootMinX[2];
  x3max = pDomain->RootMaxX[2];
  Lz = x3max - x3min;

  Nx = pDomain->Nx[0]; /* used for particle selection function */

/* Read initial conditions */
  rho0 = 1.0;
  Omega_0 = par_getd("problem","omega");
  qshear = par_getd_def("problem","qshear",1.5);
  width = par_getd_def("problem","width",0.5);
  amp = par_getd_def("problem","amp",0.2);
  ipert = par_geti_def("problem","ipert", 1);
  par_pert = par_geti_def("problem","par_pert",1);
  etavk = par_getd_def("problem","etavk",0.05);/* in unit of iso_sound (N.B.) */
  time_restore = par_getd_def("problem","time_restore",0.1);

  /* particle number */
  if (npartypes != 1)
    ath_error("[si_trap3d]: This test only allows ONE particle species!\n");

  Npar  = (int)(pow(par_geti("particle","parnumcell"),1.0/3.0));
  Npar3 = Npar*SQR(Npar);

  pGrid->nparticle         = Npar3*pGrid->Nx[0]*pGrid->Nx[1]*pGrid->Nx[2];
  grproperty[0].num = pGrid->nparticle;

  if (pGrid->nparticle+2 > pGrid->arrsize)
    particle_realloc(pGrid, pGrid->nparticle+2);

  /* set the down sampling of the particle list output
   * (by default, output 1 particle per cell)
   */
  downsamp = par_geti_def("problem","downsamp",Npar3);

  /* particle stopping time */
  tstop0[0] = par_getd("problem","tstop"); /* in code unit */
  if (par_geti("particle","tsmode") != 3)
    ath_error("[si_trap3d]: This test works only for fixed stopping time!\n");

  /* assign particle effective mass */
#ifdef FEEDBACK
  mratio = par_getd_def("problem","mratio",0.0); /* total mass fraction */
  if (mratio < 0.0)
    ath_error("[si_trap3d]: mratio must be positive!\n");
#else
  mratio = 0.0;
#endif
//  amp = amp*mratio; /* N.B.! */

#ifdef FEEDBACK
  grproperty[0].m = rho0*mratio/Npar3;
#endif

  etavk = etavk * Iso_csound; /* switch to code unit (N.B.!) */

  if (ipert == 0) {
    /* calculate NSH equilibrium velocity */
    denorm1 = 1.0/(SQR(1.0+mratio)+SQR(tstop0[0]*Omega_0));

    wxNSH = -2.0*tstop0[0]*Omega_0*denorm1*etavk;
    wyNSH = -(1.0+mratio)*denorm1*etavk;

    uxNSH = -mratio*wxNSH;
    uyNSH = -mratio*wyNSH;

    wyNSH += etavk;
  } else {
    wxNSH = wyNSH = uxNSH = uyNSH = 0.;
  }

  ath_pout(0,"etavk=%f, Iso_csound=%f\n",etavk,Iso_csound);

/* Now set initial conditions for the gas */
  t = 0.0;

  for (k=pGrid->ks; k<=pGrid->ke; k++) {
  for (j=pGrid->js; j<=pGrid->je; j++) {
  for (i=pGrid->is; i<=pGrid->ie; i++) {
    cc_pos(pGrid,i,j,k,&x1,&x2,&x3);

    rhog = rho0 * (1.+amp*exp(-x1*x1/(2.*width*width)));  
    u1 = u3 = 0.0;
    u2 = -(amp*x1/(width*width)*exp(-x1*x1/(2.*width*width)))/(1.+amp*exp(-x1*x1/(2.*width*width)))*Iso_csound*Iso_csound/(2.*Omega_0);

    pGrid->U[k][j][i].d = rhog;

    pGrid->U[k][j][i].M1 = rhog * (uxNSH+u1);
    pGrid->U[k][j][i].M2 = rhog * (uyNSH+u2);

    pGrid->U[k][j][i].M3 = rhog * u3;
#ifndef FARGO
    pGrid->U[k][j][i].M2 -= qshear*rhog*Omega_0*x1;
#endif

  }}}


/* Now set initial conditions for the particles */
  p = 0;
  Lx = pGrid->Nx[0]*pGrid->dx1;
  x1min = pGrid->MinX[0];

  Ly = pGrid->Nx[1]*pGrid->dx2;
  x2min = pGrid->MinX[1];

  Lz = pGrid->Nx[2]*pGrid->dx3;
  x3min = pGrid->MinX[2];

  for (k=pGrid->ks; k<=pGrid->ke; k++)
  {
    x3l = pGrid->MinX[2] + (k-pGrid->ks)*pGrid->dx3;
    x3u = pGrid->MinX[2] + (k-pGrid->ks+1.0)*pGrid->dx3;

    for (j=pGrid->js; j<=pGrid->je; j++)
    {
      x2l = pGrid->MinX[1] + (j-pGrid->js)*pGrid->dx2;
      x2u = pGrid->MinX[1] + (j-pGrid->js+1.0)*pGrid->dx2;

      for (i=pGrid->is; i<=pGrid->ie; i++)
      {
        x1l = pGrid->MinX[0] + (i-pGrid->is)*pGrid->dx1;
        x1u = pGrid->MinX[0] + (i-pGrid->is+1.0)*pGrid->dx1;

        cc_pos(pGrid,i,j,k,&x1,&x2,&x3);
        if (fabs(x1) > 1.5) {
        for (ip=0;ip<Npar;ip++)
        {

          if (par_pert != 1) /* quasi-uniform distribution */
            x1p = x1l+pGrid->dx1/Npar*(ip+0.5);

          for (jp=0;jp<Npar;jp++)
          {
            if (par_pert != 1) /* quasi-uniform distribution */
              x2p = x2l+pGrid->dx2/Npar*(jp+0.5);

            for (kp=0;kp<Npar;kp++)
            {
              if (par_pert == 1){ /* ramdom particle position in the grid */
                x1p = x1min + Lx*ran2(&iseed);
                x2p = x2min + Ly*ran2(&iseed);
                x3p = x3min + Lz*ran2(&iseed);
              }
              else
                x3p = x3l+pGrid->dx3/Npar*(kp+0.5);

              pGrid->particle[p].property = 0;

              pGrid->particle[p].x1 = x1p;
              pGrid->particle[p].x2 = x2p;
              pGrid->particle[p].x3 = x3p;
  
              w1 = w2 = w3 = 0.0;

              pGrid->particle[p].v1 = wxNSH+w1;
              pGrid->particle[p].v2 = wyNSH+w2;

              pGrid->particle[p].v3 = w3;
#ifndef FARGO
              pGrid->particle[p].v2 -= qshear*Omega_0*x1p;
#endif
              pGrid->particle[p].pos = 1; /* grid particle */
              pGrid->particle[p].my_id = p;
#ifdef MPI_PARALLEL
              pGrid->particle[p].init_id = myID_Comm_world;
#endif
              p += 1;
            }
          }
        }
}
      }
    }
  }

/* enroll gravitational potential function, shearing sheet BC functions */
  ShearingBoxPot = UnstratifiedDisk;
  ShBoxCoord = xy;

  return;
}

/*==============================================================================
 * PROBLEM USER FUNCTIONS:
 * problem_write_restart() - writes problem-specific user data to restart files
 * problem_read_restart()  - reads problem-specific user data from restart files
 * get_usr_expr()          - sets pointer to expression for special output data
 * get_usr_out_fun()       - returns a user defined output function pointer
 * Userwork_in_loop        - problem specific work IN     main loop
 * Userwork_after_loop     - problem specific work AFTER  main loop
 *----------------------------------------------------------------------------*/

void problem_write_restart(MeshS *pM, FILE *fp)
{
  fwrite(&rho0, sizeof(Real),1,fp);  fwrite(&mratio, sizeof(Real),1,fp);
  fwrite(&etavk, sizeof(Real),1,fp);
  fwrite(&uxNSH, sizeof(Real),1,fp); fwrite(&uyNSH, sizeof(Real),1,fp);
  fwrite(&wxNSH, sizeof(Real),1,fp); fwrite(&wyNSH, sizeof(Real),1,fp);
  fwrite(&Iso_csound, sizeof(Real),1,fp);
  return;
}

void problem_read_restart(MeshS *pM, FILE *fp)
{
  DomainS *pD = (DomainS*)&(pM->Domain[0][0]);
  GridS *pG = pD->Grid;

  ShearingBoxPot = UnstratifiedDisk;
  ShBoxCoord = xy;

  Omega_0 = par_getd("problem","omega");
  qshear = par_getd_def("problem","qshear",1.5);
  width = par_getd_def("problem","width",0.5);
  amp = par_getd_def("problem","amp",0.2);
  ipert = par_geti_def("problem","ipert", 1);
  par_pert = par_geti_def("problem","par_pert",1);
  time_restore = par_getd_def("problem","time_restore",0.1);

  Nx = pM->Nx[0];
  Npar  = (int)(sqrt(par_geti("particle","parnumcell")));
  Npar3 = SQR(Npar)*Npar;
  downsamp = par_geti_def("problem","downsamp",Npar3);

  fread(&rho0, sizeof(Real),1,fp);  fread(&mratio, sizeof(Real),1,fp);
  fread(&etavk, sizeof(Real),1,fp);
  fread(&uxNSH, sizeof(Real),1,fp); fread(&uyNSH, sizeof(Real),1,fp);
  fread(&wxNSH, sizeof(Real),1,fp); fread(&wyNSH, sizeof(Real),1,fp);
  fread(&Iso_csound, sizeof(Real),1,fp);  Iso_csound2 = SQR(Iso_csound);

  return;
}

/* difd */
static Real expr_rhodif(const GridS *pG, const int i, const int j, const int k)
{
  Real x1,x2,x3;
  cc_pos(pG,i,j,k,&x1,&x2,&x3);
  return pG->U[k][j][i].d - rho0;
}

/* dVx */
static Real expr_dVx(const GridS *pG, const int i, const int j, const int k)
{
  Real x1,x2,x3;
  cc_pos(pG,i,j,k,&x1,&x2,&x3);
  return pG->U[k][j][i].M1/pG->U[k][j][i].d - uxNSH;
}

/* dVy */
static Real expr_dVy(const GridS *pG, const int i, const int j, const int k)
{
  Real x1,x2,x3;
  cc_pos(pG,i,j,k,&x1,&x2,&x3);
#ifdef FARGO
  return pG->U[k][j][i].M2/pG->U[k][j][i].d - uyNSH;
#else
  return (pG->U[k][j][i].M2/pG->U[k][j][i].d -uyNSH + qshear*Omega_0*x1);
#endif
}

/* difdpar */
static Real expr_rhopardif(const GridS *pG,
                           const int i, const int j, const int k)
{
  Real x1,x2,x3;
  cc_pos(pG,i,j,k,&x1,&x2,&x3);
  return pG->Coup[k][j][i].grid_d - rho0*mratio;
}

/* dVxpar */
static Real expr_dVxpar(const GridS *pG, const int i, const int j, const int k)
{
  Real x1,x2,x3;
  cc_pos(pG,i,j,k,&x1,&x2,&x3);
  return expr_V1par(pG,i,j,k)-wxNSH;
}

/* dVypar */
static Real expr_dVypar(const GridS *pG, const int i, const int j, const int k)
{
  Real x1,x2,x3;
  cc_pos(pG,i,j,k,&x1,&x2,&x3);
#ifdef FARGO
  return expr_V2par(pG,i,j,k)-wyNSH;
#else
  return expr_V2par(pG,i,j,k)-wyNSH+qshear*Omega_0*x1;
#endif
}

ConsFun_t get_usr_expr(const char *expr)
{
  if(strcmp(expr,"difd")==0) return expr_rhodif;
  if(strcmp(expr,"dVx")==0) return expr_dVx;
  if(strcmp(expr,"dVy")==0) return expr_dVy;
  if(strcmp(expr,"difdpar")==0) return expr_rhopardif;
  if(strcmp(expr,"dVxpar")==0) return expr_dVxpar;
  if(strcmp(expr,"dVypar")==0) return expr_dVypar;
  return NULL;
}

VOutFun_t get_usr_out_fun(const char *name)
{
  return NULL;
}

#ifdef PARTICLES
PropFun_t get_usr_par_prop(const char *name)
{
  if (strcmp(name,"downsamp")==0) return property_mybin;
  return NULL;
}

void gasvshift(const Real x1, const Real x2, const Real x3,
                                    Real *u1, Real *u2, Real *u3)
{
  return;
}

void Userforce_particle(Real3Vect *ft, const Real x1, const Real x2,
                                       const Real x3, Real w1, Real w2, Real w3)
{
  ft->x1 -= 2.0*etavk*Omega_0;
  return;
}
#endif

void Userwork_in_loop(MeshS *pM)
{

  GridS *pG;
  DomainS *pD;
  int nl,nd,i,j,k;
  Real rhog, u2, m2;
  Real x1, x2, x3;

/*We adjust both the azimuthal velocity and gas density to approach
  their initial structure over some timescale.  Use simple Newtonian relaxation */

  for (nl=0; nl<(pM->NLevels); nl++){
    for (nd=0; nd<(pM->DomainsPerLevel[nl]); nd++){
      if (pM->Domain[nl][nd].Grid != NULL){

        pG = pM->Domain[nl][nd].Grid;
       
        for (k=pG->ks; k<=pG->ke; k++) {
          for (j=pG->js; j<=pG->je; j++) {
            for (i=pG->is; i<=pG->ie; i++) {

              cc_pos(pG,i,j,k,&x1,&x2,&x3);

              rhog = rho0 * (1.+amp*exp(-x1*x1/(2.*width*width)));  
              u2 = -(amp*x1/(width*width)*exp(-x1*x1/(2.*width*width)))/(1.+amp*exp(-x1*x1/(2.*width*width)))*Iso_csound*Iso_csound/(2.*Omega_0);
        
              if (ipert == 0){
                m2 = rhog*(u2+uyNSH);
              } else {
                m2 = rhog*u2;
              }

              if (time_restore > 0.0 && time_restore < pG->dt) time_restore = pG->dt;
          
              if (time_restore > 0.0) {
                pG->U[k][j][i].d  += -pG->dt*(pG->U[k][j][i].d -rhog)/time_restore;
                pG->U[k][j][i].M2 += -pG->dt*(pG->U[k][j][i].M2-m2)/time_restore; 
              }
            }
          }
        }
      }
    }
  }

  return;
}

/*---------------------------------------------------------------------------
 * Userwork_after_loop: computes L1-error in linear waves,
 * ASSUMING WAVE HAS PROPAGATED AN INTEGER NUMBER OF PERIODS
 * Must set parameters in input file appropriately so that this is true
 */

void Userwork_after_loop(MeshS *pM)
{
  return;
}

/*=========================== PRIVATE FUNCTIONS ==============================*/
/*--------------------------------------------------------------------------- */
/* ShearingBoxPot */
static Real UnstratifiedDisk(const Real x1, const Real x2, const Real x3)
{
  Real phi=0.0;
#ifndef FARGO
  phi -= qshear*SQR(Omega_0*x1);
#endif
  return phi;
}

/* user defined particle selection function (1: true; 0: false) */
static int property_mybin(const GrainS *gr, const GrainAux *grsub)
{
  long a,b,c,d,e,ds,sp;

  sp = MAX(downsamp/Npar3,1);         /* spacing in cells */
  ds = Npar3*sp;               /* actual dowmsampling */

  a = gr->my_id/ds;
  b = gr->my_id - a*ds;

  c = gr->my_id/(Npar3*Nx);    /* column number */
  d = c/sp;
  e = c-sp*d;

  if ((e == 0) && (b == 0) && (gr->pos == 1))
    return 1;
  else
    return 0;
}

/*------------------------------------------------------------------------------
 * ran2: extracted from the Numerical Recipes in C (version 2) code.  Modified
 *   to use doubles instead of floats. -- T. A. Gardiner -- Aug. 12, 2003
 */

#define IM1 2147483563
#define IM2 2147483399
#define AM (1.0/IM1)
#define IMM1 (IM1-1)
#define IA1 40014
#define IA2 40692
#define IQ1 53668
#define IQ2 52774
#define IR1 12211
#define IR2 3791
#define NTAB 32
#define NDIV (1+IMM1/NTAB)
#define RNMX (1.0-DBL_EPSILON)

/* Long period (> 2 x 10^{18}) random number generator of L'Ecuyer
 * with Bays-Durham shuffle and added safeguards.  Returns a uniform
 * random deviate between 0.0 and 1.0 (exclusive of the endpoint
 * values).  Call with idum = a negative integer to initialize;
 * thereafter, do not alter idum between successive deviates in a
 * sequence.  RNMX should appriximate the largest floating point value
 * that is less than 1.
 */

double ran2(long int *idum)
{
  int j;
  long int k;
  static long int idum2=123456789;
  static long int iy=0;
  static long int iv[NTAB];
  double temp;

  if (*idum <= 0) { /* Initialize */
    if (-(*idum) < 1) *idum=1; /* Be sure to prevent idum = 0 */
    else *idum = -(*idum);
    idum2=(*idum);
    for (j=NTAB+7;j>=0;j--) { /* Load the shuffle table (after 8 warm-ups) */
      k=(*idum)/IQ1;
      *idum=IA1*(*idum-k*IQ1)-k*IR1;
      if (*idum < 0) *idum += IM1;
      if (j < NTAB) iv[j] = *idum;
    }
    iy=iv[0];
  }
  k=(*idum)/IQ1;                 /* Start here when not initializing */
  *idum=IA1*(*idum-k*IQ1)-k*IR1; /* Compute idum=(IA1*idum) % IM1 without */
  if (*idum < 0) *idum += IM1;   /* overflows by Schrage's method */
  k=idum2/IQ2;
  idum2=IA2*(idum2-k*IQ2)-k*IR2; /* Compute idum2=(IA2*idum) % IM2 likewise */
  if (idum2 < 0) idum2 += IM2;
  j=(int)(iy/NDIV);              /* Will be in the range 0...NTAB-1 */
  iy=iv[j]-idum2;                /* Here idum is shuffled, idum and idum2 */
  iv[j] = *idum;                 /* are combined to generate output */
  if (iy < 1) iy += IMM1;
  if ((temp=AM*iy) > RNMX) return RNMX; /* No endpoint values */
  else return temp;
}

#undef IM1
#undef IM2
#undef AM
#undef IMM1
#undef IA1
#undef IA2
#undef IQ1
#undef IQ2
#undef IR1
#undef IR2
#undef NTAB
#undef NDIV
#undef RNMX
