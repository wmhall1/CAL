module reset
module load fftw3

./configure --with-problem=si_trap3d --with-eos=isothermal --with-gas=hydro --with-particles=feedback --enable-mpi --enable-shearing_box --enable-fargo --with-order=3p --enable-fft --with-particle_self_gravity=fft_disk

make all MACHINE=stampede2
